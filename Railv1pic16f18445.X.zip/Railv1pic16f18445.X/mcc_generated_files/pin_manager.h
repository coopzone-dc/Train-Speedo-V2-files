/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16F18444
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.31 and above
        MPLAB 	          :  MPLAB X 5.45	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set SW3 aliases
#define SW3_TRIS                 TRISAbits.TRISA2
#define SW3_LAT                  LATAbits.LATA2
#define SW3_PORT                 PORTAbits.RA2
#define SW3_WPU                  WPUAbits.WPUA2
#define SW3_OD                   ODCONAbits.ODCA2
#define SW3_ANS                  ANSELAbits.ANSA2
#define SW3_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define SW3_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define SW3_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define SW3_GetValue()           PORTAbits.RA2
#define SW3_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define SW3_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define SW3_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define SW3_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define SW3_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define SW3_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define SW3_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define SW3_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)

// get/set DIO aliases
#define DIO_TRIS                 TRISBbits.TRISB4
#define DIO_LAT                  LATBbits.LATB4
#define DIO_PORT                 PORTBbits.RB4
#define DIO_WPU                  WPUBbits.WPUB4
#define DIO_OD                   ODCONBbits.ODCB4
#define DIO_ANS                  ANSELBbits.ANSB4
#define DIO_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define DIO_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define DIO_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define DIO_GetValue()           PORTBbits.RB4
#define DIO_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define DIO_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define DIO_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define DIO_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define DIO_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define DIO_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define DIO_SetAnalogMode()      do { ANSELBbits.ANSB4 = 1; } while(0)
#define DIO_SetDigitalMode()     do { ANSELBbits.ANSB4 = 0; } while(0)

// get/set LED aliases
#define LED_TRIS                 TRISBbits.TRISB5
#define LED_LAT                  LATBbits.LATB5
#define LED_PORT                 PORTBbits.RB5
#define LED_WPU                  WPUBbits.WPUB5
#define LED_OD                   ODCONBbits.ODCB5
#define LED_ANS                  ANSELBbits.ANSB5
#define LED_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define LED_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define LED_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define LED_GetValue()           PORTBbits.RB5
#define LED_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define LED_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define LED_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELBbits.ANSB5 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELBbits.ANSB5 = 0; } while(0)

// get/set CLK aliases
#define CLK_TRIS                 TRISBbits.TRISB6
#define CLK_LAT                  LATBbits.LATB6
#define CLK_PORT                 PORTBbits.RB6
#define CLK_WPU                  WPUBbits.WPUB6
#define CLK_OD                   ODCONBbits.ODCB6
#define CLK_ANS                  ANSELBbits.ANSB6
#define CLK_SetHigh()            do { LATBbits.LATB6 = 1; } while(0)
#define CLK_SetLow()             do { LATBbits.LATB6 = 0; } while(0)
#define CLK_Toggle()             do { LATBbits.LATB6 = ~LATBbits.LATB6; } while(0)
#define CLK_GetValue()           PORTBbits.RB6
#define CLK_SetDigitalInput()    do { TRISBbits.TRISB6 = 1; } while(0)
#define CLK_SetDigitalOutput()   do { TRISBbits.TRISB6 = 0; } while(0)
#define CLK_SetPullup()          do { WPUBbits.WPUB6 = 1; } while(0)
#define CLK_ResetPullup()        do { WPUBbits.WPUB6 = 0; } while(0)
#define CLK_SetPushPull()        do { ODCONBbits.ODCB6 = 0; } while(0)
#define CLK_SetOpenDrain()       do { ODCONBbits.ODCB6 = 1; } while(0)
#define CLK_SetAnalogMode()      do { ANSELBbits.ANSB6 = 1; } while(0)
#define CLK_SetDigitalMode()     do { ANSELBbits.ANSB6 = 0; } while(0)

// get/set SW2 aliases
#define SW2_TRIS                 TRISCbits.TRISC0
#define SW2_LAT                  LATCbits.LATC0
#define SW2_PORT                 PORTCbits.RC0
#define SW2_WPU                  WPUCbits.WPUC0
#define SW2_OD                   ODCONCbits.ODCC0
#define SW2_ANS                  ANSELCbits.ANSC0
#define SW2_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define SW2_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define SW2_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define SW2_GetValue()           PORTCbits.RC0
#define SW2_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define SW2_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define SW2_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define SW2_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define SW2_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define SW2_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define SW2_SetAnalogMode()      do { ANSELCbits.ANSC0 = 1; } while(0)
#define SW2_SetDigitalMode()     do { ANSELCbits.ANSC0 = 0; } while(0)

// get/set SW1 aliases
#define SW1_TRIS                 TRISCbits.TRISC1
#define SW1_LAT                  LATCbits.LATC1
#define SW1_PORT                 PORTCbits.RC1
#define SW1_WPU                  WPUCbits.WPUC1
#define SW1_OD                   ODCONCbits.ODCC1
#define SW1_ANS                  ANSELCbits.ANSC1
#define SW1_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define SW1_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define SW1_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define SW1_GetValue()           PORTCbits.RC1
#define SW1_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define SW1_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define SW1_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define SW1_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define SW1_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define SW1_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define SW1_SetAnalogMode()      do { ANSELCbits.ANSC1 = 1; } while(0)
#define SW1_SetDigitalMode()     do { ANSELCbits.ANSC1 = 0; } while(0)

// get/set HF1 aliases
#define HF1_TRIS                 TRISCbits.TRISC2
#define HF1_LAT                  LATCbits.LATC2
#define HF1_PORT                 PORTCbits.RC2
#define HF1_WPU                  WPUCbits.WPUC2
#define HF1_OD                   ODCONCbits.ODCC2
#define HF1_ANS                  ANSELCbits.ANSC2
#define HF1_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define HF1_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define HF1_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define HF1_GetValue()           PORTCbits.RC2
#define HF1_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define HF1_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define HF1_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define HF1_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define HF1_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define HF1_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define HF1_SetAnalogMode()      do { ANSELCbits.ANSC2 = 1; } while(0)
#define HF1_SetDigitalMode()     do { ANSELCbits.ANSC2 = 0; } while(0)

// get/set HF2 aliases
#define HF2_TRIS                 TRISCbits.TRISC3
#define HF2_LAT                  LATCbits.LATC3
#define HF2_PORT                 PORTCbits.RC3
#define HF2_WPU                  WPUCbits.WPUC3
#define HF2_OD                   ODCONCbits.ODCC3
#define HF2_ANS                  ANSELCbits.ANSC3
#define HF2_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define HF2_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define HF2_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define HF2_GetValue()           PORTCbits.RC3
#define HF2_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define HF2_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define HF2_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define HF2_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define HF2_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define HF2_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define HF2_SetAnalogMode()      do { ANSELCbits.ANSC3 = 1; } while(0)
#define HF2_SetDigitalMode()     do { ANSELCbits.ANSC3 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/