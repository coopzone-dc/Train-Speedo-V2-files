/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16F18444
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "i2c_pp.h"
//#include "eeprom_simple.h"
#include <xc.h>

#define MCOUNT 20000 //around 20 seconds timeout
#define MCOUNT_MPH 5000 // timeout after displaying MPH
#define MCOUNT_INMENU 4000 //seconds to wait in menu for new press
#define DEBOUNCE 50
#define LEDTIMER 250 //250 ms flash rate for led
#define MAXMENU 2 //number of menus when sw3 is presed
#define MAXCSCALE 6 //number of supported scales
#define ESCALE 10 //eeprom memory address for cscale
#define ESDIST 11
#define MAXSDIST 2 // menu items for gap inbetween sensors 100,50,30 0-2

static uint32_t mills=0,timeout,ledflash=0;
static uint32_t SW1,SW2,SW3;
static uint8_t stage,menu,mainmenu=0;
static uint8_t ledstatus=0,ledmax=DisplayOn1,ledmin=DisplayOn1;

static uint8_t scale[] = {76,48,87,148,160,150,220};
//Disp	Scale(aprox)	Rail size
//076	1:76	 	OO
//048 	1:48 		O
//087 	1:87 		HO
//148 	1:148	 	N (UK)
//160	1:160		N (world)
//150	1:150		N (Japan)
//220	1:220	 	Z
static uint8_t sgap[] = {100,50,30}; //distance between sensors in CM
static uint8_t cscale=0;
static uint8_t sdist=0; //default sgap lookup for distance between sensors


void TMR2_int(void){
    // clear the TMR2 interrupt flag
    PIR4bits.TMR2IF = 0;
    mills++;
    if (!SW3_PORT) {SW3++;} else SW3=0;
    if (!SW2_PORT) {SW2++;} else SW2=0;
    if (!SW1_PORT) {SW1++;} else SW1=0;
    if (ledflash++ > LEDTIMER){
        ledflash=0;
        ledstatus = ~ledstatus;
        if ((ledstatus) && (ledmin != ledmax)) 
            displayBrightness(ledmin);
        else
            displayBrightness(ledmax);

    }
}
void flash(uint8_t flashbright, uint8_t flashdim) {
    ledmax=flashbright;
    ledmin=flashdim;
}
void loopReset(void) {
    uint8_t i;
    flash(DisplayOn4,DisplayOn4);
    displayClear(); //turn off dp and all digits.
    for(i=0;i<3;i++) tm_display(i,2); //turn on single row of "-"
    mills=0;
    HF1_LAT=1; HF2_LAT=1; //power on both hall effect sensors
    timeout=MCOUNT;
    LED_LAT=0;
    stage=0; menu=0;
}

void calcmph(uint32_t finishmillis)
{
 float elapsed, miles, hours, mph;
 uint16_t scaleMPH;
 
  elapsed = (float)finishmillis / 1000;    //seconds
  miles = (float)sgap[sdist] / 160934;//miles there are 160934 cm in 1 mile
  hours = elapsed / 3600;   //hours
  mph = miles / hours;
  scaleMPH = (uint16_t) (mph * (float)scale[cscale] +0.5);
   //use normal brightness if between 50 and 69 scale MPH
   //if over 70mph use bright
  flash(DisplayOn10,DisplayOn10); //default to lowest brightness
  if ((scaleMPH >= 50) && (scaleMPH < 70)) {
        flash(DisplayOn14,DisplayOn14);
    } else if (scaleMPH >= 70) {
        flash(DisplayOn14,DisplayOn1);
  }
   displayNumber((uint16_t)scaleMPH);    
}

void displayMenu(uint8_t item)
{
    displayClear();
    tm_display(1, segdata[item]);   
    tm_display(0,2+16+128); //make first display show "-"
    tm_display(2,0); // blank last display
}


void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    TMR2_SetInterruptHandler(TMR2_int);
    i2c1_init();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

cscale = (uint8_t) eeprom_read(ESCALE);
if (cscale > MAXCSCALE) //check for out of bounds value
 {
    eeprom_write(ESCALE, 0);
  cscale =0;
 }
sdist = (uint8_t) eeprom_read(ESDIST);
if (sdist > MAXSDIST) //check for out of bounds value
 {
    eeprom_write(ESCALE, 0);
  sdist =0;
 }
flash(DisplayOn1,DisplayOn4);

loopReset();    //power on reset values
timeout=2500;   //dummy timeout to allow the display of scale and gap
 displayNumber((uint16_t)scale[cscale]); //current model scale from eeprom
 __delay_ms(1250); //about 1/2 the dummy timeout above
 displayNumber((uint16_t)sgap[sdist]); //current distance between sensors from eeprom
 
//LED_LAT=1;
//__delay_ms(100);
//LED_LAT=0;
 
    while (1)
    {
        // Add your application code
        //LED_LAT = 1;
        
       if (mills > timeout) loopReset();  //back to standby display
       if (SW3 > DEBOUNCE ) 
        {
          stage=4;
          mills=0; timeout=MCOUNT_INMENU;
          mainmenu=0;
          //while (!SW3) {}; //wait for switch release
        }
       switch(stage) //normal display stages + menu 4->
        {
            case 0:
                    if(SW1 > DEBOUNCE) {
                        displayNumber(1);
                        mills=0; stage=1;
                    } 
                    if(SW2 > DEBOUNCE) {
                        displayNumber(2);
                        mills=0; stage=2;
                    }
                    break;
            case 1:
                    HF1_LAT=0; //turn off HF sensor once triggered
                    if(SW2 > DEBOUNCE) {
                        stage=3;
                    }
                    break;
            case 2:
                    HF2_LAT=0; //turn off HF
                    if(SW1 > DEBOUNCE) {
                        stage=3;
                    }
                    break;
            case 3:
                    calcmph(mills);
                    HF2_LAT=0; HF1_LAT=0; //turn off witch ever sensor was left on
                    while( (SW1 !=0) || (SW2 !=0) ) {} //wait for sensors to clear
                    mills=0; stage=0; timeout=MCOUNT_MPH;
                    while(mills < timeout){};
                    break;
             case 4:
                    while(mills < timeout) // main menu items
                    {
                        if (SW3 > DEBOUNCE)
                        {
                            while (SW3 !=0) {} //wait for the switch to be released
                            mainmenu++;
                            if (mainmenu > MAXMENU) mainmenu=0;
                            mills=0;
                            LED_LAT=1;
                            displayMenu(mainmenu);
                        }
                    }
                    mills=0;
                    switch(mainmenu)
                    {
                        case 0:
                                stage=0; //menu 0 exits back without change
                                break;
                        case 1:
                                stage=5; //menu 1 is the guage menu
                                break;   
                        case 2:
                                stage=7; //set sensor distance
                                break;
                    }
                    break;     
            case 5:
                    displayNumber((uint16_t)scale[cscale]);
                    while(mills < timeout )
                    {
                        if (SW3 > DEBOUNCE)
                        {
                            while ( SW3 !=0 ){}; //wait for release
                            cscale++;
                            if (cscale > MAXCSCALE) cscale=0;
                            mills=0; 
                            displayNumber((uint16_t)scale[cscale]);
                        }
                    }
                    mills=0;stage=6;
                    break;
            case 6:
                   displayNumber((uint16_t)scale[cscale]);
                   flash(DisplayOn14,DisplayOn1);
                   if ((uint8_t) eeprom_read(ESCALE) != cscale)
                       eeprom_write(ESCALE, (uint8_t)cscale);
                   mills=0; timeout=MCOUNT_INMENU;
                   stage=0;
                   break;
            case 7:
                    displayNumber((uint16_t)sgap[sdist]);
                    while(mills < timeout)
                    {
                        if (SW3 > DEBOUNCE)
                        {
                            while ( SW3 !=0 ){}; //wait for release
                            sdist++;
                            if (sdist > MAXSDIST) sdist=0;
                            mills=0; 
                            displayNumber((uint16_t)sgap[sdist]);
                        }
                    }
                    mills=0;stage=8;
                    break;
            case 8:
                   displayNumber((uint16_t)sgap[sdist]);
                   flash(DisplayOn14,DisplayOn1);
                   if ((uint8_t) eeprom_read(ESDIST) != sdist)
                      eeprom_write(ESDIST, sdist);
                   mills=0; timeout=MCOUNT_INMENU;
                   stage=0;
                   break;
        }
   }
}
/**
 End of File
*/