/* 
 * File:   i2c.h
 * Author: Pete
 *
 * Created on March 13, 2019, 9:36 PM
 */

#ifndef I2C_PP_H
#define	I2C_PP_H

#include <xc.h>
#include <stdint.h>

/* Modify these values for desired I2C clock frequency
 
   Fclock = Fosc /(SSP2ADD + 1)x4

   Fosc     Fcy     Fclock  BRG
   32MHz    8MHz    400KHz  0x13
   32MHz    8MHz    100KHz  0x4F
   16MHz    4MHz    400KHz  0x09
   16MHz    4MHz    100KHz  0x27
   4MHz     1MHz    100KHz  0x09
 */
#define I2C1_BRG 0x4f

// 400Khz with Fosc = 16MHz


#define ACK 1
#define NACK 0
#define i2c1_read_ack i2c1_read(ACK)
#define i2c1_read_nack i2c1_read(NACK)

/* The TM6137 uses an I2C 'like' signalling method with two caveats:
 *  1. It does not use an I2C address so you can't have any other device on the bus.
 *  2. I2C sends data MSB first, the TM6137 expects data LSB first.
 *     Since this code uses the hardware MSSP module in the PIC, the data to be sent
 *     must be reversed before loading into the PICs MSSP buffer register. 
*/

#define WriteDispAddrAuto 0x02 //0100 0000
#define WriteDispAddrFix  0x22 //0100 0100
#define AddressZero       0x03 //1100 0000

// See TM1637 datasheet page 5
// Display control table        Data Byte   Reversed        
#define DisplayOn1        0x11 //10001000   00010001
#define DisplayOn2        0x91 //10001001   10010001
#define DisplayOn4        0x51 //10001010   01010001
#define DisplayOn10       0xD1 //10001011   11010001
#define DisplayOn11       0x31 //10001100   00110001
#define DisplayOn12       0xB1 //10001101   10110001
#define DisplayOn13       0x71 //10001110   01110001
#define DisplayOn14       0xF1 //10001111   11110001
#define DisplayOff        0x01 //10000000   00000001
#define DisplayOn0 DisplayOff

// Segment data for digits 0 thru 9
uint8_t segdata[] = { 0xFC, 0x60, 0xDA, 0xF2, 0x66, 0xB6, 0xBE, 0xE0, 0xFE, 0xF6 };
uint8_t fixedPos[] = { 0x03, 0x83, 0x43, 0xc3};

// I2C functions for MSSP1 module
void i2c1_check_idle(void);
void i2c1_start(void);
void i2c1_rep_start(void);
void i2c1_stop(void);
void i2c1_write(uint8_t i2c_data);
uint8_t i2c1_read(uint8_t ack);
void i2c1_init(void);

//higher level functions
void displayNumber(uint16_t num);
void displayClear();
void tm_display(uint8_t BitAddr, uint8_t DispData);
void displayBrightness(uint8_t b);



#ifdef	__cplusplus
extern "C" {
#endif

#ifdef	__cplusplus
}
#endif

#endif	/* I2C_PP_H */

